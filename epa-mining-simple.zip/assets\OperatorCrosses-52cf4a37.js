import{L as a,k as o}from"./ProjectionTransformation-a6d9b195.js";class n extends a{getOperatorType(){return 6}execute(e,r,t,s){return o(e,r,t,16,s)}}export{n as t};
