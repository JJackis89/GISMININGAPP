const e={geodesic:0,loxodrome:1,"great-elliptic":2,"normal-section":3,"shape-preserving":4};export{e};
