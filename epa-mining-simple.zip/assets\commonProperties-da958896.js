const t={type:String,json:{read:{source:"token"},write:{target:"token"}}};export{t};
