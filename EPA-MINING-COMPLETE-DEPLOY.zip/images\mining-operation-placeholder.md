<!-- This file represents the mining operation image that will be used on the login page -->
<!-- The actual image file should be saved as mining-operation.jpg in this directory -->
<!-- Image shows mining trucks and equipment in an open-pit mining operation -->
