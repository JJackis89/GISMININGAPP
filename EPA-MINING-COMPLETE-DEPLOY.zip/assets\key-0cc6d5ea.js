import{g as s,h as n,E as i}from"./IdentityManager-1ceefb93.js";import{m as o}from"./component-a37a48f6.js";/**
 * @license
 * Copyright 2021 Google LLC
 * SPDX-License-Identifier: BSD-3-Clause
 */const c=s(class extends n{constructor(){super(...arguments),this.key=i}render(t,e){return this.key=t,e}update(t,[e,r]){return e!==this.key&&(o(t),this.key=e),r}});/*! All material copyright ESRI, All Rights Reserved, unless otherwise specified.
See https://github.com/Esri/calcite-design-system/blob/dev/LICENSE.md for details.
v3.2.1 */function m(t){return t==="Enter"||t===" "}const h=["0","1","2","3","4","5","6","7","8","9"];export{m as a,c as i,h as n};
