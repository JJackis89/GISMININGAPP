import{C as u}from"./index-f771b285.js";function l(r,n){return r===null?n:new u({url:r.field("url")})}export{l};
